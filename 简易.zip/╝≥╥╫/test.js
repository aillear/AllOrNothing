import { get_score } from "./get_score"
console.log("nimabi")
let a = [2,4,3,1,5]
let score_1 = new get_score
console.log(score_1.arr)

